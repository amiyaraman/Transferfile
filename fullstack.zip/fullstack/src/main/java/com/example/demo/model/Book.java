package com.example.demo.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Book {
    @Id
    private String id;
    private String bkname;
    private String bkprice;

    public Book() {}

    public Book(String id, String bkname, String bkprice) {
        this.id = id;
        this.bkname = bkname;
        this.bkprice = bkprice;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getBkname() {
        return bkname;
    }

    public void setBkname(String bkname) {
        this.bkname = bkname;
    }

    public String getBkprice() {
        return bkprice;
    }

    public void setBkprice(String bkprice) {
        this.bkprice = bkprice;
    }
}
