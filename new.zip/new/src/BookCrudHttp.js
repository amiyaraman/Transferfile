import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './App.css';

function BookCrudHttp() {
  const [books, setBooks] = useState([]);
  const [newBook, setNewBook] = useState({
    bkname: '',
    bkprice: '',
    id: ''
  });
  const [editingBook, setEditingBook] = useState(null);

  useEffect(() => {
    fetchBooks();
  }, []);

  const fetchBooks = async () => {
    try {
      const response = await axios.get('http://localhost:8080/api/books');
      setBooks(response.data);
    } catch (error) {
      console.error('Error fetching books: ', error);
    }
  };

  const addBook = async () => {
    try {
      if (!newBook.bkname || !newBook.bkprice || !newBook.id) {
        alert('Name, price, and ID cannot be empty');
        return;
      }

      if (books.find(book => book.id === newBook.id)) {
        alert('ID already exists. Please choose a unique ID.');
        return;
      }

      await axios.post('http://localhost:8080/api/books', newBook);
      setBooks([...books, newBook]);
      setNewBook({ bkname: '', bkprice: '', id: '' });
    } catch (error) {
      console.error('Error adding book: ', error);
    }
  };

  const deleteBook = async (id) => {
    try {
      await axios.delete(`http://localhost:8080/api/books/${id}`);
      setBooks(books.filter(book => book.id !== id));
    } catch (error) {
      console.error('Error deleting book: ', error);
    }
  };

  const updateBook = async (book) => {
    try {
      if (!book.bkname || !book.bkprice || !book.id) {
        alert('Name, price, and ID cannot be empty');
        return;
      }

      await axios.put(`http://localhost:8080/api/books/${book.id}`, book);
      setEditingBook(null);
    } catch (error) {
      console.error('Error updating book: ', error);
    }
  };

  const handleChange = (e, id) => {
    const { name, value } = e.target;
    setEditingBook({ ...editingBook, [name]: value });
  };

  const handleEdit = (book) => {
    setEditingBook(book);
  };

  const handleUpdate = async () => {
    await updateBook(editingBook);
    fetchBooks(); // Refresh books list after update
  };

  return (
    <div className="book-manager">
      <h1>CRUD ON BOOKS</h1>
      <form className="add-book-form" onSubmit={addBook}>
        <label>
          Book Name: <br />
          <input
            type="text"
            name="bkname"
            value={newBook.bkname}
            onChange={(e) => setNewBook({ ...newBook, bkname: e.target.value })}
          />
        </label>
        <br />
        <label>
          Book Price: <br />
          <input
            type="text"
            name="bkprice"
            value={newBook.bkprice}
            onChange={(e) => setNewBook({ ...newBook, bkprice: e.target.value })}
          />
        </label>
        <br />
        <label>
          ID: <br />
          <input
            type="text"
            name="id"
            value={newBook.id}
            onChange={(e) => setNewBook({ ...newBook, id: e.target.value })}
          />
        </label>
        <br />
        <button className='add-button' type="submit">Add Book</button>
      </form><hr />
      <table className="book-table">
        <thead>
          <tr>
            <th>Book Name</th>
            <th>Book Price</th>
            <th>ID</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          {books.map(book => (
            <tr key={book.id} className="book-item">
              <td>
                <input
                  type="text"
                  name="bkname"
                  value={book.id === editingBook?.id ? editingBook.bkname : book.bkname}
                  onChange={(e) => handleChange(e, book.id)}
                  disabled={editingBook?.id !== book.id}
                  className="book-input"
                />
              </td>
              <td>
                <input
                  type="text"
                  name="bkprice"
                  value={book.id === editingBook?.id ? editingBook.bkprice : book.bkprice}
                  onChange={(e) => handleChange(e, book.id)}
                  disabled={editingBook?.id !== book.id}
                  className="book-input"
                />
              </td>
              <td>
                <span className="book-id">{book.id}</span>
              </td>
              <td>
                <button onClick={() => deleteBook(book.id)} className="delete-button">Delete</button>
                {editingBook?.id === book.id && <button onClick={handleUpdate} className="update-button">Update</button>}
                {editingBook?.id !== book.id && <button onClick={() => handleEdit(book)} className="edit-button">Edit</button>}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );

}

export default BookCrudHttp;
